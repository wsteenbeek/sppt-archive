# Vancouver crime data

TODO: add information about where this came from, licenses, etc.

The files are:
 - **points1**: Vancouver_OpenDataCrime_2012_UTM
 - **points2**: Vancouver_OpenDataCrime_2013_UTM
 - **areas:**: Vancouver_2006_CTs